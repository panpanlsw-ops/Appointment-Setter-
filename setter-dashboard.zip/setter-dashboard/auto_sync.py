"""
auto_sync.py - copy the latest CRM data into the dashboard's Google Sheet.

Schedule it to run every 15 minutes on a computer that can reach the CRM
database (see "Keep the sheet up to date automatically" in README.md).
Each run re-pulls every worksheet in full, so new appointments AND changes
to existing rows (status flags, dates) both show up.

Settings live in sync_secrets.toml next to this file (git-ignored).
A log of every run is written to sync_log.txt.
"""
import logging
import sys
import time
import tomllib
from pathlib import Path

import mysql.connector
import pandas as pd

import sync_to_sheet as sheet

HERE = Path(__file__).resolve().parent
RETRIES = 3
WAIT_SECONDS = 60

logging.basicConfig(filename=HERE / "sync_log.txt", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")


def run_once(cfg):
    sheet.SHEET_URL = cfg["sheet"]["url"]
    sheet.KEY_FILE = str(HERE / cfg["sheet"]["key_file"])
    cnx = mysql.connector.connect(**cfg["mysql"])
    try:
        for worksheet, query in sheet.QUERIES.items():
            df = pd.read_sql(query, cnx)
            sheet.write_df(df, worksheet)
            logging.info("%s: %s rows", worksheet, f"{len(df):,}")
    finally:
        cnx.close()


def main():
    with open(HERE / "sync_secrets.toml", "rb") as f:
        cfg = tomllib.load(f)
    for attempt in range(1, RETRIES + 1):
        try:
            run_once(cfg)
            logging.info("sync finished")
            return 0
        except Exception as err:
            logging.exception("attempt %d of %d failed: %s", attempt, RETRIES, err)
            if attempt < RETRIES:
                time.sleep(WAIT_SECONDS)
    return 1


if __name__ == "__main__":
    sys.exit(main())
