@echo off
REM Runs auto_sync.py from this folder. Task Scheduler calls this file.
cd /d "%~dp0"
python auto_sync.py
