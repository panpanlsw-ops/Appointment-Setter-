# Appointment Setter Dashboard

A Streamlit dashboard that reads everything from one Google Sheet and refreshes every 10 minutes (plus a **Refresh now** button).

1. **Phone calls**: GoTo call history (inbound, outbound, talk time per person and per phone line), month to date by default.
2. **Setter performance**: leads, appointments, quotes and orders per setter, with Apt / Leads and Order / Apt (Jan 2025 – Sep 2026).
3. **Sales vs setters**: each sales rep's own results next to the appointments setters handed them.

## Files

```
app.py                            the dashboard
sync_to_sheet.py                  copies CRM data into the sheet (queries live here)
auto_sync.py                      runs the copy on a schedule so new appointments show up
run_sync.bat                      Windows launcher for Task Scheduler
sync_secrets.toml.example         template for the database login used by auto_sync.py
requirements.txt                  Python packages
.streamlit/config.toml            colors and theme
.streamlit/secrets.toml.example   template for the sheet link, Google key and password
.gitignore                        keeps secrets and key files out of GitHub
```

## 1. Set up the Google Sheet

Each dashboard tab reads its own worksheets, so you can connect them one at a time.
Row 1 of each worksheet holds the headers; extra columns are fine. The names below are set
at the top of `app.py` (`LEADS_COLS`, `APT_COLS`, `GOTO_COLS`) if yours differ.

**Setter performance**

| Worksheet      | Columns used                                                                 |
|----------------|------------------------------------------------------------------------------|
| `leads_create` | `leads_id`, `marketing date`, `mark_salesname`                               |
| `apt_created`  | `leads_id`, `first_created`, `apt salesname`, `final_status`, `orders salesrepsname` |

- Leads = unique `leads_id` per setter, by `marketing date`.
- Appointments = unique `leads_id` per setter, by `first_created`.
- Cancelled = `final_status` is "Cancelled"; everything else counts as active.
- Orders = appointments with any value in `orders salesrepsname`.
- If `path` and `path_detail` exist, they show in the appointment list.

**Phone calls**: a `calls` worksheet with the GoTo call history export pasted as-is.

**Sales vs setters**: not connected to the new sheet layout yet.

To fill the sheet from your Jupyter notebook instead of by hand, use `sync_to_sheet.py`:

```python
from sync_to_sheet import sync_all, write_df
sync_all(getCrmData)                                       # reps, leads, appointments, quotes, orders
write_df(pd.read_csv("goto_call_history.csv"), "calls")   # GoTo export
```

## Keep the sheet up to date automatically

`auto_sync.py` re-pulls every tab from the CRM and rewrites the sheet, so new appointments,
quotes and orders appear, and so do changes to existing rows (a flag flipping to TRUE,
a new date). Run it on a computer that can reach the CRM database and stays on during
work hours, ideally an office PC or server rather than a laptop.

1. Put these files in one folder on that computer: `sync_to_sheet.py`, `auto_sync.py`,
   `run_sync.bat`, and the service account `.json` key.
2. Copy `sync_secrets.toml.example` to `sync_secrets.toml` and fill in the database login
   and sheet url. Share the sheet with the service account as **Editor**.
3. Test it once: double-click `run_sync.bat`, then check `sync_log.txt` and the sheet.
4. Schedule it every 15 minutes. Open Command Prompt and run (change the path):

   ```
   schtasks /Create /SC MINUTE /MO 15 /TN "Setter dashboard sync" /TR "C:\setter-dashboard\run_sync.bat"
   ```

   To stop it later: `schtasks /Delete /TN "Setter dashboard sync" /F`

New CRM data reaches the dashboard within about 25 minutes (15 for the sync, 10 for the
dashboard's refresh), or sooner with **Refresh now**. The `calls` tab still needs the
GoTo export pasted in, or `write_df(pd.read_csv(...), "calls")`, unless you connect the
GoTo API.

If a run fails (database or internet down), it retries 3 times, one minute apart, and
writes the error to `sync_log.txt`. The sheet keeps the last good data until the next
successful run.

## 2. Create a Google service account (one time)

This lets the dashboard read a private sheet.

1. Go to https://console.cloud.google.com and create a project (any name).
2. **APIs & Services → Library**: enable **Google Sheets API**.
3. **IAM & Admin → Service Accounts → Create service account**. No roles needed.
4. Open it → **Keys → Add key → JSON**. A `.json` file downloads. Keep it private and never put it on GitHub.
5. In your Google Sheet, click **Share** and add the service account's `client_email` (from the JSON). **Viewer** is enough for the dashboard; use **Editor** if you'll run `sync_to_sheet.py`.

## 3. Run it on your computer

```bash
pip install -r requirements.txt
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# fill in the sheet url and copy the fields from the JSON key into [gcp_service_account]
streamlit run app.py
```

Without the `[gsheet]` and `[gcp_service_account]` sections, the app runs on demo data.

## 4. Put it on GitHub

```bash
git init
git add .
git commit -m "Appointment setter dashboard"
git branch -M main
git remote add origin https://github.com/<your-account>/setter-dashboard.git
git push -u origin main
```

Make the repository **private**. Run `git status` before the first push and make sure `secrets.toml` and the `.json` key are not listed.

## 5. Deploy on Streamlit Community Cloud

1. Go to https://share.streamlit.io and sign in with GitHub.
2. Click **Create app**, choose the repository, branch `main`, main file `app.py`.
3. **Advanced settings → Secrets**: paste the contents of your `secrets.toml`.
4. Click **Deploy**.

Every push to `main` updates the app. New data in the sheet shows up within 10 minutes, or right away with **Refresh now**.

Set `APP_PASSWORD` in secrets so only people with the password can see the data.
